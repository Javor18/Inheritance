from project.motorcycle import Motorcycle

class CrossMotorcycle(Motorcycle):

    def __int__(self, fuel, horse_power):
        super().__init__(fuel, horse_power)